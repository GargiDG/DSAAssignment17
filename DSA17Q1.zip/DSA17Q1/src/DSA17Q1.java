
import java.util.HashMap;

public class DSA17Q1 {
    public static int firstUniqChar(String s) {
        // Create a HashMap to store the character frequencies
        HashMap<Character, Integer> freqMap = new HashMap<>();

        // Traverse the string and count the frequency of each character
        for (char c : s.toCharArray()) {
            freqMap.put(c, freqMap.getOrDefault(c, 0) + 1);
        }

        // Traverse the string again and find the first character with frequency 1
        for (int i = 0; i < s.length(); i++) {
            if (freqMap.get(s.charAt(i)) == 1) {
                return i; // Return the index of the first non-repeating character
            }
        }

        return -1; // If no non-repeating character is found, return -1
    }

    public static void main(String[] args) {
        String s = "aabb";
        int index = firstUniqChar(s);
        System.out.println("First non-repeating character index: " + index);
    }
}
