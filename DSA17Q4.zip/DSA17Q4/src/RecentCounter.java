import java.util.LinkedList;
import java.util.Queue;

public class RecentCounter {
    private Queue<Integer> requests;

    public RecentCounter() {
        requests = new LinkedList<>();
    }

    public int ping(int t) {
        // Add the new request time to the queue
        requests.add(t);

        // Remove requests that are older than the time frame [t - 3000, t]
        while (requests.peek() < t - 3000) {
            requests.poll();
        }

        // Return the number of requests in the time frame
        return requests.size();
    }

    public static void main(String[] args) {
    	RecentCounter counter = new RecentCounter();
        int[] timestamps = {1, 100, 3001, 3002};

        for (int timestamp : timestamps) {
            int count = counter.ping(timestamp);
            System.out.println("Number of recent requests: " + count);
        }
    }
}
