
public class DSA17Q5 {
	public static int findTheWinner(int n, int k) {
	        int ans = 0;
	        for(int i = 1; i <= n; i++)
	        {
	            ans = (ans + k) % i;
	        }
	        return ans + 1;
	    }
	public static void main(String[] args) {
		int n = 6;
		int k = 5;
		int winner = findTheWinner(n,k);
		System.out.println(winner);
		
	}

}
