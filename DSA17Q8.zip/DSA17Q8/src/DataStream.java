
import java.util.LinkedList;
import java.util.Queue;

public class DataStream  {
    private int value;
    private int k;
    private Queue<Integer> stream;

    public DataStream (int value, int k) {
        this.value = value;
        this.k = k;
        stream = new LinkedList<>();
    }

    public boolean consec(int num) {
        stream.add(num);

        if (stream.size() < k) {
            return false;
        }

        if (stream.size() > k) {
            stream.poll();
        }

        for (int element : stream) {
            if (element != value) {
                return false;
            }
        }

        return true;
    }

    public static void main(String[] args) {
    	DataStream  ds = new DataStream (4, 3);
        int[] nums = {4, 4, 4, 3};

        for (int num : nums) {
            boolean result = ds.consec(num);
            System.out.println("Result: " + result);
        }
    }
}
